"use client";
import {useCallback,useEffect,useRef,useState,type RefObject} from 'react';
import type {PuppetScene} from './puppet-scene';
import {EXPRESSION_SOURCE_SHA,freshExpressions,saveExpressions,type ExpressionImage,type ExpressionLibrary} from './expression-library';
import {FaceRigCapture,freshFaceRig,parseFaceRig,neutralRigFace,smoothRigFace,type FaceRig2D,type RigChannel} from './face-rig';
import type {PerformanceFrame} from './rig';

export type FaceRigMode='live'|'test'|'reference';
const KEY='frameflow.face-rig2d.v1.cat-2d-v1';
export function useFaceRigController(scene:RefObject<PuppetScene|null>,ready:boolean){
  const [profile,setProfileState]=useState(()=>freshFaceRig(EXPRESSION_SOURCE_SHA));
  const profileRef=useRef(profile),capture=useRef(new FaceRigCapture()),values=useRef(neutralRigFace()),manual=useRef(neutralRigFace());
  const [manualValues,setManualValues]=useState(neutralRigFace);
  const [library,setLibrary]=useState<ExpressionLibrary>(freshExpressions),[mode,setModeState]=useState<FaceRigMode>('live'),modeRef=useRef<FaceRigMode>('live');
  const [telemetry,setTelemetry]=useState({values:neutralRigFace(),raw:{} as Record<string,number>,detected:false,progress:0,calibrating:false,message:'웹캠을 연결하고 무표정을 보정하세요.',limited:false});
  const lastUi=useRef(0),[error,setError]=useState(''),[loaded,setLoaded]=useState(false);
  const setProfile=useCallback((next:FaceRig2D)=>{const valid=parseFaceRig(next,EXPRESSION_SOURCE_SHA);profileRef.current=valid;setProfileState(valid);setError('');},[]);
  useEffect(()=>{let active=true;void Promise.resolve().then(()=>{if(!active)return;try{const saved=localStorage.getItem(KEY);if(saved)setProfile(parseFaceRig(JSON.parse(saved),EXPRESSION_SOURCE_SHA));}catch{setError('저장된 얼굴 리그를 읽지 못해 기본 기준점을 열었습니다.');}setLoaded(true);});return()=>{active=false;};},[setProfile]);
  useEffect(()=>{if(!ready||!loaded)return;let active=true;void scene.current?.configureFaceRig(profile,library).then(()=>{if(active){scene.current?.setLiveFace(modeRef.current!=='reference');setError('');}}).catch(e=>{if(active)setError(e instanceof Error?e.message:'얼굴 리그 준비 실패');});return()=>{active=false;};},[ready,loaded,profile,library,scene]);
  const setMode=useCallback((next:FaceRigMode)=>{modeRef.current=next;setModeState(next);manual.current=neutralRigFace();setManualValues(manual.current);scene.current?.setLiveFace(next!=='reference');if(next==='reference'){const entry=library.entries.find(e=>e.id===library.selected);if(entry)void scene.current?.setExpression(entry,library.strength,library.transition_ms).catch(()=>setError('제작 자료 이미지를 표시하지 못했습니다.'));}},[scene,library]);
  const receive=useCallback((frame:PerformanceFrame,now:number)=>{
    const changed=capture.current.receive(frame.expressions??{},frame.faceDetected??(frame.faceLandmarks?.length??0)>=400,now,profileRef.current);
    if(changed)setProfile({...profileRef.current,channels:{...profileRef.current.channels,...changed}});
  },[setProfile]);
  const tick=useCallback((now:number,dt:number)=>{
    const target=modeRef.current==='live'?capture.current.target(now,profileRef.current):modeRef.current==='test'?manual.current:neutralRigFace();
    values.current=smoothRigFace(values.current,target,dt,profileRef.current.smoothing);scene.current?.setFaceRigValues(values.current);
    if(now-lastUi.current>90){lastUi.current=now;setTelemetry({values:values.current,raw:capture.current.raw,detected:capture.current.detected&&now-capture.current.lastSeen<500,progress:capture.current.samples?.length??0,calibrating:!!capture.current.samples,message:capture.current.message,limited:scene.current?.faceRigLimited??false});}
  },[scene]);
  const test=useCallback((key:RigChannel,value:number)=>{modeRef.current='test';setModeState('test');scene.current?.setLiveFace(true);manual.current={...manual.current,[key]:Math.max(0,Math.min(1,value))};setManualValues(manual.current);},[scene]);
  const clearTest=useCallback(()=>{manual.current=neutralRigFace();setManualValues(manual.current);values.current=neutralRigFace();scene.current?.setFaceRigValues(values.current);},[scene]);
  const resetCapture=useCallback(()=>{capture.current.reset();},[]);
  const calibrate=useCallback((key:'neutral'|RigChannel)=>{capture.current.begin(key,performance.now());},[]);
  const preview=useCallback(async(entry:ExpressionImage,strength:number,duration:number)=>{if(modeRef.current==='reference')await scene.current?.setExpression(entry,strength,duration);},[scene]);
  const save=useCallback(async()=>{await saveExpressions(library);localStorage.setItem(KEY,JSON.stringify(parseFaceRig(profileRef.current,EXPRESSION_SOURCE_SHA)));},[library]);
  return {profile,setProfile,library,setLibrary,mode,setMode,telemetry,manualValues,error,receive,tick,test,clearTest,resetCapture,calibrate,preview,save};
}
