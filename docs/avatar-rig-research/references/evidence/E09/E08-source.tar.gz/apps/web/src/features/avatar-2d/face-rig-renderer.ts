import * as THREE from 'three';
import {expressionRect,type ExpressionLibrary} from './expression-library';
import {FACE_CROP,FACE_POINT_IDS,FACE_POSE_IDS,FACE_CHANNELS_2D,RIG_CHANNEL_META,solveFacePoints,neutralRigFace,type FaceRig2D,type FacePoint,type FacePoseId,type RigFaceValues,type FaceRegion} from './face-rig';
import {triangulateFace,affineTriangle,safeFaceDeformation,type FaceTriangle} from './face-triangulation';

const SCALE=2;
const canvas=()=>{const c=document.createElement('canvas');c.width=FACE_CROP.width*SCALE;c.height=FACE_CROP.height*SCALE;return c;};
const local=(p:FacePoint):FacePoint=>[(p[0]-FACE_CROP.x)*SCALE,(p[1]-FACE_CROP.y)*SCALE];
/** All source textures are warped to ONE interpolated landmark mesh before compositing. */
export class FaceRigRenderer {
  readonly canvas=canvas();readonly texture=new THREE.CanvasTexture(this.canvas);
  ready=false;limited=false;
  private profile:FaceRig2D|null=null;
  private plates=new Map<FacePoseId,HTMLCanvasElement>();
  private warped=new Map<FacePoseId,HTMLCanvasElement>();
  private cache=new Map<string,Promise<HTMLCanvasElement>>();
  private triangles:FaceTriangle[]=[];private revision=0;private disposed=false;private last=0;
  private lastSignature='';private currentValues=neutralRigFace();
  private stage=canvas();private mask=canvas();
  constructor(){this.texture.colorSpace=THREE.SRGBColorSpace;this.texture.generateMipmaps=false;this.texture.minFilter=THREE.LinearFilter;}
  async configure(profile:FaceRig2D,library:ExpressionLibrary){
    const revision=++this.revision;
    const images=await Promise.all(FACE_POSE_IDS.map(async pose=>{
      const entry=library.entries.find(e=>e.id===profile.poses[pose].imageId);if(!entry)throw new Error(`${pose} 기준 이미지가 없습니다. 제작 자료 연결을 확인하세요.`);
      const rect=expressionRect(entry),key=JSON.stringify([entry.image,rect]);
      if(!this.cache.has(key)){this.cache.set(key,(async()=>{const image=new Image();image.src=entry.image;await image.decode();const c=canvas(),ctx=c.getContext('2d')!;ctx.drawImage(image,(rect[0]-FACE_CROP.x)*SCALE,(rect[1]-FACE_CROP.y)*SCALE,rect[2]*SCALE,rect[3]*SCALE);return c;})().catch(error=>{this.cache.delete(key);throw error;}));}
      return [pose,await this.cache.get(key)!] as const;
    }));
    if(this.disposed||revision!==this.revision)return;
    this.profile=profile;this.plates=new Map(images);this.triangles=triangulateFace(FACE_POINT_IDS.map(id=>profile.poses.neutral.points[id]));
    FACE_POSE_IDS.forEach(id=>{if(!this.warped.has(id))this.warped.set(id,canvas());});this.ready=true;this.last=0;this.lastSignature='';this.render(this.currentValues,performance.now(),true);
  }
  private warp(pose:FacePoseId,points:FacePoint[]){
    const c=this.warped.get(pose)!,ctx=c.getContext('2d')!,source=this.plates.get(pose)!;
    const from=FACE_POINT_IDS.map(id=>local(this.profile!.poses[pose].points[id])),to=points.map(local);
    ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,c.width,c.height);ctx.drawImage(source,0,0);
    for(const t of this.triangles){const target=t.map(i=>to[i]),matrix=affineTriangle(t.map(i=>from[i]),target);if(!matrix)continue;
      const center:FacePoint=[target.reduce((s,p)=>s+p[0],0)/3,target.reduce((s,p)=>s+p[1],0)/3];
      ctx.save();ctx.beginPath();target.forEach((p,i)=>{const x=p[0]+(p[0]-center[0])*.006,y=p[1]+(p[1]-center[1])*.006;if(i)ctx.lineTo(x,y);else ctx.moveTo(x,y);});ctx.closePath();ctx.clip();ctx.setTransform(...matrix);ctx.drawImage(source,0,0);ctx.restore();
    }
    return c;
  }
  render(values:RigFaceValues,now:number,force=false){
    this.currentValues=values;
    if(!this.ready||!this.profile||(!force&&now-this.last<1000/24))return;this.last=now;
    const signature=FACE_CHANNELS_2D.map(k=>Math.round(values[k]*1000)).join(',');if(!force&&signature===this.lastSignature)return;this.lastSignature=signature;
    const solved=solveFacePoints(this.profile,values),rest=FACE_POINT_IDS.map(id=>this.profile!.poses.neutral.points[id]);
    const safe=safeFaceDeformation(rest,FACE_POINT_IDS.map(id=>solved[id]),this.triangles);this.limited=safe.limited;
    const base=this.warp('neutral',safe.points),ctx=this.canvas.getContext('2d')!;ctx.clearRect(0,0,this.canvas.width,this.canvas.height);ctx.drawImage(base,0,0);
    const regions:FaceRegion[]=['mouth','leftEye','rightEye','leftBrow','rightBrow'];
    const rendered=new Map<FacePoseId,HTMLCanvasElement>([['neutral',base]]);
    for(const region of regions){
      const weights=new Map<FacePoseId,number>();
      for(const key of FACE_CHANNELS_2D){if(RIG_CHANNEL_META[key].gaze||!RIG_CHANNEL_META[key].regions.includes(region)||!this.profile.channels[key].enabled)continue;let weight=values[key];if(region==='mouth'&&key!=='jawOpen')weight*=.5;if(weight>.008){const pose=this.profile.channels[key].pose;weights.set(pose,(weights.get(pose)??0)+weight);}}
      if(region==='mouth'&&values.jawOpen>.035&&this.profile.channels.jawOpen.enabled){weights.clear();weights.set(this.profile.channels.jawOpen.pose,Math.min(1,values.jawOpen/.22));}
      const sum=[...weights.values()].reduce((a,b)=>a+b,0);if(sum<.008)continue;
      const sc=this.stage.getContext('2d')!;sc.clearRect(0,0,this.stage.width,this.stage.height);sc.globalCompositeOperation='source-over';sc.globalAlpha=Math.max(0,1-sum);sc.drawImage(base,0,0);sc.globalCompositeOperation='lighter';
      for(const [pose,weight]of weights){if(!rendered.has(pose))rendered.set(pose,this.warp(pose,safe.points));sc.globalAlpha=weight/Math.max(1,sum);sc.drawImage(rendered.get(pose)!,0,0);}
      sc.globalAlpha=1;sc.globalCompositeOperation='destination-in';
      const mc=this.mask.getContext('2d')!;mc.clearRect(0,0,this.mask.width,this.mask.height);
      const ids=FACE_POINT_IDS.filter(id=>region==='mouth'?id.startsWith('mouth'):region.endsWith('Brow')?id.startsWith(region):id.startsWith(region)||id===region.replace('Eye','Iris'));
      const center:FacePoint=[ids.reduce((s,id)=>s+solved[id][0],0)/ids.length,ids.reduce((s,id)=>s+solved[id][1],0)/ids.length];const p=local(center);
      const rx=region==='mouth'?34:region.endsWith('Brow')?32:33,ry=region==='mouth'?27:region.endsWith('Brow')?17:23;
      mc.save();mc.translate(...p);mc.scale(rx*SCALE,ry*SCALE);const gradient=mc.createRadialGradient(0,0,.65,0,0,1);gradient.addColorStop(0,'#fff');gradient.addColorStop(1,'#fff0');mc.fillStyle=gradient;mc.fillRect(-1,-1,2,2);mc.restore();
      sc.drawImage(this.mask,0,0);sc.globalCompositeOperation='source-over';ctx.drawImage(this.stage,0,0);
    }
    this.texture.needsUpdate=true;
  }
  dispose(){this.disposed=true;this.revision++;this.texture.dispose();this.cache.clear();this.plates.clear();this.warped.clear();}
}
